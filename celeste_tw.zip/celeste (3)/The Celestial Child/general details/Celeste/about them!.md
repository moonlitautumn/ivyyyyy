### Pics / picrews :
![[2307052_ZM9oHU8y.png]]![[1588687_YYnwIUcz.png]]![[1588687_3uLaoh0W.png]]![[1588687_mXnCb8h1.png]]
### general details :
***name*** : Celeste Aloe
***age now*** (14/03/2045) : 15yo
***nationality*** : canadian
***sexuality*** : sapphi ace
***pronouns*** : they/them
***birthday*** : 14/03/2030

***family*** :
    ~~Mother~~ : ==(unnamed shadow)==
	    ![[about her!]]
	~~Father~~ : ==(unnamed shadow)==
	Older Brother :
		![[about him!]]

### personality :
![[general details/Celeste/personality|personality]]


### About!

*main article:*
[[backstory]]

- horns represent antisocial tendencies/family trauma, it also represents how unlike their brother, they protect themself not by nescessarily pushing others away with anger when they get too close but by just not being open about their emotions. (its more of a passive/defensive protection measure)
- their halo represents how some people (namely their parents) pressure them to be perfect, despite their obvious flaws 
- tends to distance themself from others out of fear of failing their expectations or making them feel bad, and because they therefore drain their social battery
- tries to put on the act that they dont care and are appathetic about things but (really) deep down cares deeply about others.. maybe even more that she cares for herself.. They tend to always get hurt in the end because of it.
- doesnt really know who they actually are because of how they hide their emotions.
- thinks of death as an escape and as somthing that brings "peace". ~~uses her scarf to hide previous atempts~~
- keeps a *cute* boxcutter on them at all times

**likes**: 
- gaming (psychological horror and shooters)
- taking pictures
- black cats
- sleeping
- books
- plushies
- ~~cutting~~
- being alone
- the rain
- snow
- loud things and music, expecially vocaloid and sad songs.
- playing the bass
- their brother
- their bed/room
- their parents..?
- amethyst
- the colour dark red on white
- fire
- *~~prefered method: hanging~~*

**dislikes**
- people/socializing
- playing the bass..
- soup for some reason
- the heat
- conflict
- school
- talking
- "the shadows"
- most men
- crouded places

**weaknesses**
- pressure
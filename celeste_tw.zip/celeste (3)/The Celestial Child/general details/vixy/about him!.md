### Pics / Picrews :
![[2307052_oskQ63fz.png]]
![[1588687_0MLmy0at.png]]![[1588687_JMa6Slj6.png]]![[1588687_7RhNmabO.png]]
### General details :
***name*** : vix or vixy Aloe
***age*** : 16yo
***sexuality*** : bi
***pronouns*** : he/him
***birthday*** : 5/12/2028

***family*** :
    Mother : ==(unnamed shadow)==
	Father : ==(unnamed shadow)==
	Younger sibling :
		![[about them!]]

***friends*** :
	 Madeline or Maddie : [[general details/vixy/his friends/Madeline/about her!|about her!]]
	 Arthur "ash" : [[general details/vixy/his friends/arthur/about him!|about him!]]
	 Ebony or Ebby :[[about her]]
### personality :
![[general details/vixy/personality|personality]]



### about!

main article:
[[general details/vixy/backstory|backstory]]

- wings represent how he saved Celeste.
- horns represent agressive tendencies, how he pushes people away, keeps them at a distance and doesnt let them get *too* close. (its more of an active/offensive protection measure)
- accidentally severely hurts one of the shadows while protecting Celeste on the day before the recital, he sees them as shadows too after he notices what his ~~parents~~ were doing was abuse.
- thinks of death as the permanent ending of a live and sees it as something extremely serious... for himself he sees death as a "too permanent" means for peace and quiet, might atempt if things get too bad though.
- plays the guitar for a long time and is really good at it, he agreed to play with Celeste and one of his friends, Ebony, who is a drummer at the school Recital.
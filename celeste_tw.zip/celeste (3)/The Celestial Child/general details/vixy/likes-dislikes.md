**likes**:
- dogs
- moss
- videogames (namely shooters and minecraft)
- loud music, breakcore, rock and some vocaloid
- his friends (to be elaborated/named)
- the moon
- crows
- *~~prefered method: cut wrists~~*
- his mother
- playing the guitar

**dislikes:**
- the shadows
- conflict
- capitalism
- the cold
- crowds
- most people (other than his friends)
- Celeste (partially)

**weaknesses**
- isolation
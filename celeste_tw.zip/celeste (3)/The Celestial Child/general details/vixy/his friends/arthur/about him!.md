![[2307052_2gegsCog.png]]
***name*** : arthur "ash"
***age*** : 14
***sexuality*** : vincian (mlm)
***pronouns*** : he/they
***birthday*** : 26/07/2030

- likes studying and is trying his best to get best marks on his exams.
- tends to prioritize his studies and his "future" above anything else (including his friends)
- despite this he still makes time to hang out with their friendgroup.
- is anxious about his future so he tries to guarantee that things will go well for him, no matter if it affects others or not.

to be elaborated but he is one of Vixys "friends" that end up abandoning him
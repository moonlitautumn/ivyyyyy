likes: 
- studying
- minecraft
- lofi and ambient music (doesnt play an instrument though)
- dark academia aesthetic
- *prioritising himself*
- reading

dislikes:
- horror

weaknesses:
- confrontation
### Pics / Picrews :
![[2307052_3UrbZ2Fi.png]]
![[1588687_my5YrKdD.png]]![[1588687_ylgWYr1w.png]]![[1588687_DGk6A8if.png]]
### General details :
***name*** : Ebony or Ebby
***age*** : 15yo
***sexuality*** : pan
***pronouns*** : she/it
***birthday*** : 24/03/2029 (~~you love me?~~)

### personality
![[general details/vixy/his friends/Ebony (drummer)/personality|personality]]

### about! 

- dog ears represent loyalty and how she "loves like a dog".
- "tentacles" represent repressed and hidden trauma + the occasional halucination.
- pre recital she plays the drums and is the emotionally closest to Vixy in his friendgroup.
- she agreed to play in the recital with Vixy because they were the only two out of the friend group that knew how to play and because she wanted to get to know his sibling.
- feels like she doesnt belong with Vixy and his friends because of anxiety.
- doesnt really know Celeste and thinks of them as "Vixys sibling" only, she wants to be closer to them though.
- post recital shes the only one out of Vixys friend group that cares about what happened (the others dont even know something happened), but she initially tries to distance herself from vixy out of fear because he literally killed his own father, and she doesnt help much because it would be too costly on her own mental health... or does she?, in reality she tries to help Vixy and Celeste but doesnt want to step over their boundraries and prefers to give them space to process their emotions, Vixy seems to want to believe she doesnt want to help as an "excuse to isolate himself and get worse."
- she sometimes texts Vixy and asks if he's okay.. it feels *shallow* to Vixy though... ~~*Celeste doesnt have the same privelege.*~~ (at first)
- in reality she doesnt text  Celeste because she overthinks and believes that if she texts first she will come off as weird or needy, so she prefers to connect with Vixy first.
- wants to help Vixy (and by extension Celeste) because they were friends previously and she wouldnt just abandon him like that... (~~maybe she understands..?~~)
- she is planning on killing herself right after helping the duo but neither Celeste nor Vixy notice, she hopes that by helping them overcome their problems she will be able to help herself. she might atempt when she thinks her "job is done", that she has helped them enough, and that therefore because it didnt help her deal with her own problems or cure her she doesnt have a reason for living anymore. ==Celeste cant save her==
- her mother died in a fire two years ago when she was 13yrs old, shes the one that got her disgnosed and was taking her to therapy, she seemed to actually care despite working as much as her husband. her father is absent because of work so she lives alone most of the time, she resents this and feels abandoned by him.
- had a lot of scars even when everything seemed fine (pre recital) but hides them really well.
- post incident she hangsout less with her main friend group because she is disguested by their lack of care for Vixy.
- thinks of death as sweet.
- has a crush on Celeste and will never be able to be with them because she believes that she is unlovable and broken, and that therefore it would be unfair for Celeste to be with her instead of someone that would be "better", despite that she at some point has hope but gets the vibe Celeste would never like her back because of how distant and cold they act, solidifying that idea, but she hopes that with her sacrifice they will live their life to the fullest, and keep living.
- sometimes halucinates (what she halucinates is to be elaborated), tends to ignore it, and hide it like everything else; really well.


> *("it would be a punch in the gut for her to suddenly khs ==and actually die== right when things are starting to get better, not decided though,
> maybe the duo will only decide to keep going because it would honour her death, and because the last thing that she wanted to do before her death, "save them".")*
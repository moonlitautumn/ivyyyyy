**likes**:
- breakcore, vocaloid and sad songs, tbh anything
- ~~prefered method: overdose~~
- *~~cutting ~~*
- 2014 vibes
- people
- fashion

**dislikes**:
- people that lie
- being alone

**weaknesses**:
- gossip about her
- manipulation

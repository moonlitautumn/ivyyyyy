![[2307052_uu4GARh3.png]]
***name*** : madeline or maddie
***age*** : 16
***sexuality*** : bi
***pronouns*** : she/her
***birthday*** : 20/11/2028


- she is a mostly ~~cheery person~~ *she bottles up her issues*.
- doesnt play an instrument but would like to try some day!
- because of bottling up her own issues and never conforting them she doesnt have the emotional space or the ability to support someone who is struggling.
- she forgot how to support others emotionally long ago.
- her parents are supportive but she still doesnt talk much about her feelings with them.


to be elaboratedddd
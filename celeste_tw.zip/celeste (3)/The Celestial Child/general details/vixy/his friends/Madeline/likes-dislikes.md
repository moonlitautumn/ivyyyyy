likes
- her appearance 
- social media

dislikes
- exams
- 

weaknesses
- 

![[2307052_R4uKstW1 1.png]]
***name*** : ~~will~~ "*unknown*" Aloe
***age now*** : 5x?
***nationality*** : canadian?
***sexuality*** : ???
***pronouns*** : he/him
***birthday*** : ???

### personality :
![[general details/'shadows'/father/personality|personality]]

### about!
![[general details/'shadows'/father/backstory|backstory]]
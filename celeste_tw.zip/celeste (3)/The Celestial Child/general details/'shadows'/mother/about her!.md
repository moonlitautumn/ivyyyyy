![[20240624_021630.png]]***name*** : ~~Clover~~ "*unknown*" Aloe
***age now*** : ~~4x~~ ???
***nationality*** : ~~canadian~~ hell
***sexuality*** : ???
***pronouns*** : ~~she/her~~ it/its
***birthday*** : ???

### personality :
![[general details/'shadows'/mother/personality]]

### about!

main article
[[general details/'shadows'/mother/backstory|backstory]]

- doesnt instantly disown Vixy for murdering her husband because she is being abused by him.
- tries to keep up the act that everything is fine and tends to convince herself that what happens to her and what she does is normal and correct.
- her name means "Think of me".
- broken ~~past repair~~ because of physical and emotional abuse.
- ==*just wants to be loved.*==
- used to play her mothers bass but gave up after getting married.
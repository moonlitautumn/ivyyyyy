**likes**:
- cats
- her grandmothers bass
- her childrien
- her husband..?

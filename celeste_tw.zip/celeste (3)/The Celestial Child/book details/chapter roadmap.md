### month 1:
- **chapter** 1:
	- intro to the main characters,
	- shows their parents as sweet and caring but drops some hints something is wrong
	- talks how despite their family being "perfect" Celeste isolates herself in her room and always has bandages on their arms / face.
	
- **chapter 2:** 
	- talks about their school life and how they dont have many friends but how they also dont care much about that. (she does care)
	- shows Vixy with his friends at school having fun or talking while Celeste looks at them, showing some slight discomfort.
	- Celeste and Vixy walk home together not sharing a word, Celeste trys to start a conversation but Vixy ignores them.
	- celeste gets home and is instantly told by their mother in a "sweet tone" to practice for the recital, she seems excited but tired and goes to her room to practice. Vixy on the other hand doesnt get told to do anything, he goes to his room.
- ch3:
- ch4
- ch5